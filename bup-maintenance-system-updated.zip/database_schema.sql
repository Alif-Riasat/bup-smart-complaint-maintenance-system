-- ====================================================================
-- BUP Smart Complaint & Maintenance Management System
-- MySQL Database Schema & Sample Data
-- ====================================================================
-- To import and view this database in your MySQL Terminal:
-- 1. mysql -u root -p
-- 2. CREATE DATABASE IF NOT EXISTS bup_maintenance;
-- 3. USE bup_maintenance;
-- 4. SOURCE database_schema.sql;
-- ====================================================================

CREATE DATABASE IF NOT EXISTS bup_maintenance CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bup_maintenance;

-- 1. Users Table
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    phone VARCHAR(50) NOT NULL,
    user_type ENUM('student', 'faculty', 'officer', 'staff', 'admin') NOT NULL,
    role ENUM('student', 'faculty', 'officer', 'maintenance', 'admin', 'authority') NOT NULL,
    student_or_employee_id VARCHAR(50) UNIQUE NOT NULL,
    department_name VARCHAR(150) NOT NULL,
    avatar_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Departments Table
DROP TABLE IF EXISTS departments;
CREATE TABLE departments (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    contact_info VARCHAR(100) NOT NULL,
    head_name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL
);

-- 3. Maintenance Staff / Servicers Table
DROP TABLE IF EXISTS maintenance_staff;
CREATE TABLE maintenance_staff (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    department_id VARCHAR(50) NOT NULL,
    department_name VARCHAR(150) NOT NULL,
    specialization VARCHAR(150) NOT NULL,
    active_tasks INT DEFAULT 0
);

-- 4. Campus Locations Table
DROP TABLE IF EXISTS campus_locations;
CREATE TABLE campus_locations (
    id VARCHAR(50) PRIMARY KEY,
    building_name VARCHAR(150) NOT NULL,
    floor VARCHAR(50) NOT NULL,
    room_area VARCHAR(150) NOT NULL
);

-- 5. Complaint Categories Table
DROP TABLE IF EXISTS complaint_categories;
CREATE TABLE complaint_categories (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    icon_name VARCHAR(50),
    department_id VARCHAR(50),
    default_priority ENUM('Low', 'Medium', 'High', 'Emergency') DEFAULT 'Medium'
);

-- 6. Emergency Contacts Table
DROP TABLE IF EXISTS emergency_contacts;
CREATE TABLE emergency_contacts (
    id VARCHAR(50) PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    category VARCHAR(150) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    mobile VARCHAR(50) NOT NULL,
    ext VARCHAR(50),
    location VARCHAR(150),
    availability VARCHAR(100)
);

-- 7. Complaints Table
DROP TABLE IF EXISTS complaints;
CREATE TABLE complaints (
    id VARCHAR(50) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    category_id VARCHAR(50) NOT NULL,
    category_name VARCHAR(150) NOT NULL,
    priority ENUM('Low', 'Medium', 'High', 'Emergency') NOT NULL DEFAULT 'Medium',
    status ENUM('Pending', 'Assigned', 'In Progress', 'Resolved', 'Closed', 'Rejected') NOT NULL DEFAULT 'Pending',
    submitted_by VARCHAR(50) NOT NULL,
    submitted_by_name VARCHAR(150) NOT NULL,
    submitted_by_role VARCHAR(50) NOT NULL,
    assigned_staff_id VARCHAR(50),
    assigned_staff_name VARCHAR(150),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL
);

-- ====================================================================
-- Sample Seed Data
-- ====================================================================

-- Insert Sample Users
INSERT INTO users (id, name, email, phone, user_type, role, student_or_employee_id, department_name) VALUES
('user-nusrat', 'Nusrat Jahan', 'nusrat.24549010088@bup.edu.bd', '+880 1712-334455', 'student', 'student', '24549010088', 'BICE 2024, Dept of ICT, FST'),
('user-saha', 'Suman Saha', 'suman.saha@bup.edu.bd', '+880 1711-889900', 'faculty', 'faculty', 'FAC-IOT-108', 'Department of ICT, FST'),
('user-zahid', 'Col (Retd) Zahid Hasan', 'admin.maintenance@bup.edu.bd', '+880 1711-000101', 'admin', 'admin', 'ADM-BUP-001', 'Central Campus Maintenance Administration'),
('user-rafiqul', 'Rafiqul Islam', 'rafiqul.maint@bup.edu.bd', '+880 1711-234567', 'staff', 'maintenance', 'STF-ELEC-401', 'Electrical & Mechanical Wing');

-- Insert Sample Maintenance Servicers
INSERT INTO maintenance_staff (id, name, email, phone, department_id, department_name, specialization, active_tasks) VALUES
('staff-1', 'Rafiqul Islam', 'rafiqul.maint@bup.edu.bd', '+880 1711-234567', 'dept-electrical', 'Electrical & Mechanical Wing', 'HVAC, AC Chillers & Electrical Wiring', 2),
('staff-2', 'Tariqul Alam', 'tariqul.ict@bup.edu.bd', '+880 1819-345678', 'dept-ict', 'ICT & Network Support Desk', 'Campus Wi-Fi, Fiber Optic & Hardware', 1),
('staff-3', 'Nurul Huda', 'nurul.estate@bup.edu.bd', '+880 1912-456789', 'dept-estate', 'Estate & Maintenance Office', 'Plumbing, Water Lines & Civil Works', 1),
('staff-4', 'Kamrul Hasan', 'kamrul.transport@bup.edu.bd', '+880 1515-567890', 'dept-transport', 'Transport & Shuttle Service Office', 'Shuttle Fleet Operations & Vending Ops', 1);

-- Insert Sample Emergency Numbers
INSERT INTO emergency_contacts (id, title, category, phone, mobile, ext, location, availability) VALUES
('ctrl', 'BUP Central Control Room', '24/7 Operations & Security', '+880 2-8000441', '+880 1711-000101', 'Ext. 101/102', 'Admin Building GF', '24 Hours / 7 Days'),
('med', 'Medical Center & Ambulance', 'Health & First Aid', '+880 2-8000445', '+880 1711-000112', 'Ext. 119', 'Hostel Complex GF', '24 Hours Emergency'),
('sec', 'Campus Security & Proctor', 'Discipline & Safety', '+880 2-8000448', '+880 1819-000223', 'Ext. 111', 'Main Gate Security', 'Round the Clock'),
('elec', 'Electrical & AC Emergency Wing', 'Power & Lift Outage', '+880 2-8000452', '+880 1713-000334', 'Ext. 114', 'Substation Block', '8:00 AM – 10:00 PM'),
('ict', 'ICT Network NOC Helpdesk', 'Wi-Fi & Server Issues', '+880 2-8000455', '+880 1714-000445', 'Ext. 115', 'Academic Block 1 Room 401', '8:30 AM – 6:00 PM'),
('fire', 'Fire Safety & Disaster Response', 'Emergency Evacuation', '+880 2-8000465', '+880 1717-000778', 'Ext. 999/105', 'Safety Command Office', '24 Hours Emergency');

-- Insert Sample Complaints
INSERT INTO complaints (id, title, description, category_id, category_name, priority, status, submitted_by, submitted_by_name, submitted_by_role, assigned_staff_id, assigned_staff_name) VALUES
('BUP-CMP-2026-001', 'Split AC cooling failure in IoT Lab 402', 'The master air conditioner unit is making loud clicking sounds and blowing warm air.', 'cat-electrical', 'Electrical & Mechanical', 'High', 'In Progress', 'user-nusrat', 'Nusrat Jahan', 'student', 'staff-1', 'Rafiqul Islam'),
('BUP-CMP-2026-002', 'Access Point offline in Library 2nd Floor', 'Wi-Fi signal drops completely near study carrels.', 'cat-ict', 'ICT & Network', 'Medium', 'Pending', 'user-saha', 'Suman Saha', 'faculty', NULL, NULL);
