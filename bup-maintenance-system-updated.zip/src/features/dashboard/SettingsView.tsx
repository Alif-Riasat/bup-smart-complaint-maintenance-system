import React, { useState } from 'react';
import {
  Settings,
  User,
  Bell,
  Shield,
  RotateCcw,
  Download,
  CheckCircle2,
  AlertTriangle,
  Building2,
  Lock,
  Mail,
  Phone,
  HelpCircle,
  ExternalLink
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { downloadProjectZip } from '../../utils/zipExporter';

export const SettingsView: React.FC = () => {
  const { currentUser, resetToDefaultData, availableUsers, logout } = useApp();

  const [emailAlerts, setEmailAlerts] = useState(true);
  const [smsUrgent, setSmsUrgent] = useState(true);
  const [dailyDigest, setDailyDigest] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const handleReset = () => {
    resetToDefaultData();
    setShowResetConfirm(false);
    setResetSuccess(true);
    setTimeout(() => setResetSuccess(false), 3000);
  };

  const handleDownload = async () => {
    try {
      setIsExporting(true);
      await downloadProjectZip();
    } catch (err) {
      console.error(err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-8 font-sans pb-16 max-w-4xl text-zinc-900">
      {/* Header */}
      <div>
        <div className="text-xs text-zinc-400 mb-1">
          Administration / <span className="text-zinc-600 font-medium">Settings</span>
        </div>
        <h1 className="text-3xl font-extrabold text-zinc-900 tracking-tight">
          System &amp; Account Settings
        </h1>
        <p className="text-sm text-zinc-500 mt-1">
          Manage your personal profile, notification dispatch channels, and maintenance parameters.
        </p>
      </div>

      {resetSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Demo complaints and staff assignments have been successfully reset to proposal defaults.</span>
        </div>
      )}

      {/* Profile Card */}
      <div className="p-6 sm:p-8 rounded-2xl bg-white border border-zinc-200/90 shadow-xs space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-zinc-100">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-black text-white font-extrabold text-lg flex items-center justify-center shadow-xs">
              {currentUser.name.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <h2 className="text-lg font-bold text-zinc-900">{currentUser.name}</h2>
              <p className="text-xs text-zinc-500">{currentUser.departmentName}</p>
            </div>
          </div>

          <span className="px-3 py-1 rounded-full text-xs font-bold bg-zinc-100 text-zinc-800 uppercase tracking-wider border border-zinc-200">
            {currentUser.role}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-3.5 rounded-xl bg-zinc-50 border border-zinc-200">
            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">
              Institutional Email
            </span>
            <span className="font-semibold text-zinc-900">{currentUser.email}</span>
          </div>

          <div className="p-3.5 rounded-xl bg-zinc-50 border border-zinc-200">
            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">
              Student / Employee ID
            </span>
            <span className="font-mono font-bold text-zinc-900">{currentUser.studentOrEmployeeId}</span>
          </div>

          <div className="p-3.5 rounded-xl bg-zinc-50 border border-zinc-200">
            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">
              Emergency Phone
            </span>
            <span className="font-mono font-medium text-zinc-900">{currentUser.phone || '+880 1700-000000'}</span>
          </div>

          <div className="p-3.5 rounded-xl bg-zinc-50 border border-zinc-200">
            <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">
              Portal Permissions
            </span>
            <span className="font-semibold text-zinc-900">
              {currentUser.role === 'admin'
                ? 'Full Administration (Triage, RBAC, Dispatch)'
                : currentUser.role === 'maintenance'
                ? 'Field Technician (Repair, Resolution Logging)'
                : 'Campus Submitter (File Tickets, Track Progress)'}
            </span>
          </div>
        </div>
      </div>

      {/* Notification Preferences */}
      <div className="p-6 sm:p-8 rounded-2xl bg-white border border-zinc-200/90 shadow-xs space-y-5">
        <div>
          <h2 className="text-base font-bold text-zinc-900">Notification Preferences</h2>
          <p className="text-xs text-zinc-500 mt-0.5">Choose how you want to be notified about ticket lifecycle changes</p>
        </div>

        <div className="space-y-3.5">
          <label className="flex items-center justify-between p-3.5 rounded-xl bg-zinc-50 border border-zinc-200 cursor-pointer">
            <div>
              <span className="font-bold text-xs text-zinc-900 block">Instant Email Alerts</span>
              <span className="text-[11px] text-zinc-500">Receive email notification when technician is dispatched or issue is marked resolved</span>
            </div>
            <input
              type="checkbox"
              checked={emailAlerts}
              onChange={(e) => setEmailAlerts(e.target.checked)}
              className="w-4 h-4 rounded text-black accent-black cursor-pointer"
            />
          </label>

          <label className="flex items-center justify-between p-3.5 rounded-xl bg-zinc-50 border border-zinc-200 cursor-pointer">
            <div>
              <span className="font-bold text-xs text-zinc-900 block">Urgent SMS Alerts</span>
              <span className="text-[11px] text-zinc-500">Direct mobile SMS message for Emergency level facility hazards</span>
            </div>
            <input
              type="checkbox"
              checked={smsUrgent}
              onChange={(e) => setSmsUrgent(e.target.checked)}
              className="w-4 h-4 rounded text-black accent-black cursor-pointer"
            />
          </label>

          <label className="flex items-center justify-between p-3.5 rounded-xl bg-zinc-50 border border-zinc-200 cursor-pointer">
            <div>
              <span className="font-bold text-xs text-zinc-900 block">Daily Activity Digest</span>
              <span className="text-[11px] text-zinc-500">Summary of all campus repairs completed at the end of each working day</span>
            </div>
            <input
              type="checkbox"
              checked={dailyDigest}
              onChange={(e) => setDailyDigest(e.target.checked)}
              className="w-4 h-4 rounded text-black accent-black cursor-pointer"
            />
          </label>
        </div>
      </div>

      {/* Demo Controls & System Maintenance */}
      <div className="p-6 sm:p-8 rounded-2xl bg-white border border-zinc-200/90 shadow-xs space-y-5">
        <div>
          <h2 className="text-base font-bold text-zinc-900">Demonstration &amp; Data Tools</h2>
          <p className="text-xs text-zinc-500 mt-0.5">Manage evaluation state or export full source code</p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setShowResetConfirm(true)}
            className="px-4 py-2.5 rounded-xl bg-zinc-100 hover:bg-zinc-200 text-xs font-semibold text-zinc-800 flex items-center gap-2 transition-colors cursor-pointer border border-zinc-200"
          >
            <RotateCcw className="w-4 h-4 text-zinc-600" />
            <span>Reset Demo Data to Proposal Default</span>
          </button>

          <button
            onClick={handleDownload}
            disabled={isExporting}
            className="px-4 py-2.5 rounded-xl bg-black hover:bg-zinc-800 text-white text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer shadow-xs disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{isExporting ? 'Exporting...' : 'Export Project Code (ZIP)'}</span>
          </button>
        </div>
      </div>

      {/* Confirmation Dialog */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 space-y-4 border border-zinc-200 shadow-2xl">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-zinc-900">Reset Demo Data?</h3>
              <p className="text-xs text-zinc-600 mt-1 leading-relaxed">
                This will reload all preloaded complaints, audit trail history, and technician workloads as defined in the BUP capstone proposal.
              </p>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-4 py-2 rounded-xl border border-zinc-200 text-xs font-semibold text-zinc-700 hover:bg-zinc-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleReset}
                className="px-4 py-2 rounded-xl bg-black hover:bg-zinc-800 text-white text-xs font-semibold cursor-pointer"
              >
                Confirm Reset
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
