import React, { useState } from 'react';
import {
  Wrench,
  Play,
  CheckCircle2,
  Clock,
  Building2,
  User,
  Phone,
  Check,
  X
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Complaint } from '../../types/complaint';

interface MaintenanceTasksViewProps {
  onSelectComplaint: (id: string) => void;
}

export const MaintenanceTasksView: React.FC<MaintenanceTasksViewProps> = ({
  onSelectComplaint,
}) => {
  const { complaints, updateStaffProgress, currentUser } = useApp();

  const [resolvingComplaint, setResolvingComplaint] = useState<Complaint | null>(null);
  const [resolutionRemarks, setResolutionRemarks] = useState('');

  const technicianTasks = complaints.filter(
    (c) => c.assignedStaffId || c.status === 'Assigned' || c.status === 'In Progress'
  );

  const handleStartWork = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    updateStaffProgress(
      id,
      'In Progress',
      `Technician ${currentUser.name} has arrived on site and commenced work.`
    );
  };

  const handleOpenResolve = (c: Complaint, e: React.MouseEvent) => {
    e.stopPropagation();
    setResolvingComplaint(c);
    setResolutionRemarks('');
  };

  const handleSubmitResolve = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resolvingComplaint || !resolutionRemarks.trim()) return;
    updateStaffProgress(resolvingComplaint.id, 'Resolved', resolutionRemarks.trim());
    setResolvingComplaint(null);
  };

  return (
    <div className="space-y-6 font-sans pb-16">
      <div>
        <div className="text-xs text-zinc-400 mb-1">
          Technician / <span className="text-zinc-600 font-medium">Assigned work orders</span>
        </div>
        <h1 className="text-3xl font-extrabold text-zinc-900 tracking-tight">
          Assigned Work Orders
        </h1>
        <p className="text-sm text-zinc-500 mt-1">
          Field technician dispatch queue for diagnostics, on-site repair, and resolution logging.
        </p>
      </div>

      <div className="space-y-3">
        {technicianTasks.length === 0 ? (
          <div className="p-12 text-center bg-white border border-zinc-200 rounded-2xl">
            <Wrench className="w-10 h-10 text-zinc-400 mx-auto mb-3" />
            <h3 className="text-sm font-bold text-zinc-900">No active work orders</h3>
            <p className="text-xs text-zinc-500 mt-1">You are all caught up!</p>
          </div>
        ) : (
          technicianTasks.map((t) => (
            <div
              key={t.id}
              onClick={() => onSelectComplaint(t.id)}
              className="p-5 rounded-2xl bg-white border border-zinc-200 hover:border-black/30 transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4 cursor-pointer shadow-xs"
            >
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-zinc-900">{t.id}</span>
                  <span className="text-zinc-400">•</span>
                  <span className="text-xs font-semibold text-zinc-600">{t.categoryName}</span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-zinc-100 text-zinc-700">
                    {t.priority}
                  </span>
                </div>

                <h3 className="font-bold text-zinc-900 text-sm">{t.title}</h3>
                <p className="text-xs text-zinc-500 line-clamp-1">{t.description}</p>

                <div className="flex items-center gap-4 text-xs text-zinc-500 pt-1">
                  <span className="flex items-center gap-1 text-zinc-800 font-medium">
                    <Building2 className="w-3.5 h-3.5 text-zinc-400" />
                    {t.buildingName} · {t.roomArea}
                  </span>
                  <span>Contact: {t.userName} ({t.userPhone})</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-zinc-100 text-zinc-800">
                  {t.status}
                </span>

                {t.status === 'Assigned' && (
                  <button
                    onClick={(e) => handleStartWork(t.id, e)}
                    className="px-3.5 py-2 rounded-xl bg-black hover:bg-zinc-800 text-white text-xs font-semibold flex items-center gap-1.5"
                  >
                    <Play className="w-3 h-3" />
                    <span>Start work</span>
                  </button>
                )}

                {t.status === 'In Progress' && (
                  <button
                    onClick={(e) => handleOpenResolve(t, e)}
                    className="px-3.5 py-2 rounded-xl bg-black hover:bg-zinc-800 text-white text-xs font-semibold flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Mark resolved</span>
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Resolve Dialog */}
      {resolvingComplaint && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl border border-zinc-200">
            <div className="flex items-center justify-between pb-2 border-b border-zinc-100">
              <h3 className="font-bold text-sm text-zinc-900">Complete &amp; Resolve Work Order</h3>
              <button
                onClick={() => setResolvingComplaint(null)}
                className="text-zinc-400 hover:text-zinc-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-zinc-600">
              Ticket: <strong className="text-zinc-900">{resolvingComplaint.title}</strong> ({resolvingComplaint.id})
            </p>

            <form onSubmit={handleSubmitResolve} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-zinc-800 mb-1">
                  Resolution notes &amp; actions taken
                </label>
                <textarea
                  rows={4}
                  required
                  value={resolutionRemarks}
                  onChange={(e) => setResolutionRemarks(e.target.value)}
                  placeholder="Describe repair actions (e.g. replaced power breaker, cleared drain blockage, updated router config)..."
                  className="w-full bg-zinc-50 border border-zinc-200 rounded-xl p-3 text-xs text-zinc-900 focus:outline-none focus:border-black"
                />
              </div>

              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setResolvingComplaint(null)}
                  className="px-4 py-2 rounded-xl border border-zinc-200 text-xs font-semibold text-zinc-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-black hover:bg-zinc-800 text-white text-xs font-semibold"
                >
                  Submit &amp; Mark Resolved
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
