import React from 'react';
import { Users, ShieldCheck, Wrench, GraduationCap, Briefcase } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const UsersAccessView: React.FC = () => {
  const { availableUsers, maintenanceStaff } = useApp();

  return (
    <div className="space-y-6 font-sans pb-16">
      <div>
        <div className="text-xs text-zinc-400 mb-1">
          Administration / <span className="text-zinc-600 font-medium">Users &amp; access</span>
        </div>
        <h1 className="text-3xl font-extrabold text-zinc-900 tracking-tight">
          Users &amp; Access Control
        </h1>
        <p className="text-sm text-zinc-500 mt-1">
          Role-Based Access Control (RBAC) governing portal capabilities across BUP stakeholders.
        </p>
      </div>

      {/* Users Table */}
      <div className="rounded-2xl bg-white border border-zinc-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-zinc-100 flex items-center justify-between">
          <h2 className="font-bold text-sm text-zinc-900">Campus Stakeholders Directory</h2>
          <span className="text-xs text-zinc-500">{availableUsers.length} Registered Accounts</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-zinc-50/70 border-b border-zinc-100 text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
              <tr>
                <th className="px-6 py-3.5">USER</th>
                <th className="px-6 py-3.5">ID / SECTION</th>
                <th className="px-6 py-3.5">EMAIL</th>
                <th className="px-6 py-3.5">ROLE PRIVILEGE</th>
                <th className="px-6 py-3.5">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {availableUsers.map((u) => (
                <tr key={u.id} className="hover:bg-zinc-50/80 transition-colors">
                  <td className="px-6 py-4">
                    <div className="font-bold text-zinc-900">{u.name}</div>
                    <div className="text-[11px] text-zinc-400">{u.departmentName}</div>
                  </td>
                  <td className="px-6 py-4 font-mono font-medium text-zinc-700">
                    {u.studentOrEmployeeId}
                  </td>
                  <td className="px-6 py-4 text-zinc-600">{u.email}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      u.role === 'admin'
                        ? 'bg-black text-white'
                        : u.role === 'maintenance'
                        ? 'bg-orange-100 text-orange-900 border border-orange-300'
                        : 'bg-zinc-100 text-zinc-800'
                    }`}>
                      {u.role === 'admin' ? 'Administrator' : u.role === 'maintenance' ? 'Field Technician' : u.role}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-emerald-700 font-semibold flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                      Active
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Field Technicians Workload Table */}
      <div className="rounded-2xl bg-white border border-zinc-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-zinc-100 flex items-center justify-between">
          <h2 className="font-bold text-sm text-zinc-900">Maintenance Technicians Workload</h2>
          <span className="text-xs text-zinc-500">{maintenanceStaff.length} On Duty</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-zinc-50/70 border-b border-zinc-100 text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
              <tr>
                <th className="px-6 py-3.5">TECHNICIAN</th>
                <th className="px-6 py-3.5">DEPARTMENT</th>
                <th className="px-6 py-3.5">SPECIALIZATION</th>
                <th className="px-6 py-3.5">ACTIVE TASKS</th>
                <th className="px-6 py-3.5">PHONE</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {maintenanceStaff.map((s) => (
                <tr key={s.id} className="hover:bg-zinc-50/80 transition-colors">
                  <td className="px-6 py-4 font-bold text-zinc-900">{s.name}</td>
                  <td className="px-6 py-4 text-zinc-600">{s.departmentName}</td>
                  <td className="px-6 py-4 text-zinc-600">{s.specialization}</td>
                  <td className="px-6 py-4 font-bold text-zinc-900">
                    <span className="px-2 py-0.5 rounded-md bg-zinc-100 border border-zinc-200">
                      {s.activeTasksCount} active
                    </span>
                  </td>
                  <td className="px-6 py-4 font-mono text-zinc-600">{s.phone}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
