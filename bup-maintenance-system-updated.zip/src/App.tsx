import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { LoginPage } from './features/auth/LoginPage';
import { Sidebar, NavItemKey } from './components/Sidebar';
import { Header } from './components/Header';
import { OverviewView } from './features/dashboard/OverviewView';
import { MyComplaintsView } from './features/dashboard/MyComplaintsView';
import { NewComplaintView } from './features/dashboard/NewComplaintView';
import { NotificationsView } from './features/dashboard/NotificationsView';
import { SettingsView } from './features/dashboard/SettingsView';
import { AllComplaintsAdminView } from './features/admin/AllComplaintsAdminView';
import { AdminAnalyticsView } from './features/admin/AdminAnalyticsView';
import { UsersAccessView } from './features/admin/UsersAccessView';
import { CategoriesLocationsView } from './features/admin/CategoriesLocationsView';
import { MaintenanceTasksView } from './features/maintenance/MaintenanceTasksView';
import { ComplaintDetailModal } from './features/user/ComplaintDetailModal';
import { NotificationDrawer } from './components/NotificationDrawer';
import { HelpDeskModal } from './components/HelpDeskModal';
import { CommandPaletteModal } from './components/CommandPaletteModal';

function AppContent() {
  const { currentUser, isAuthenticated } = useApp();

  // Navigation
  const [currentNav, setCurrentNav] = useState<NavItemKey>('overview');

  // Modals & Drawers state
  const [selectedComplaintId, setSelectedComplaintId] = useState<string | null>(null);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isHelpDeskOpen, setIsHelpDeskOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // 1. If not authenticated, show Login & Landing Page
  if (!isAuthenticated) {
    return <LoginPage />;
  }

  // Compute Page Title for Top Bar
  const getPageTitle = () => {
    switch (currentNav) {
      case 'overview':
        return 'Overview';
      case 'new-complaint':
        return 'New complaint';
      case 'my-complaints':
        return 'My complaints';
      case 'notifications':
        return 'Notifications';
      case 'admin-analytics':
        return 'Admin analytics';
      case 'all-complaints':
        return 'All complaints';
      case 'users-access':
        return 'Users & access';
      case 'categories-locations':
        return 'Categories & locations';
      case 'reports-activity':
        return 'Reports & activity';
      case 'settings':
        return 'Settings';
      case 'maintenance-tasks':
        return 'Assigned work orders';
      default:
        return 'Overview';
    }
  };

  return (
    <div className="min-h-screen bg-[#faf8f5] flex font-sans text-zinc-900 selection:bg-black selection:text-white">
      {/* Left Dark Sidebar with Mobile Drawer */}
      <Sidebar
        currentNav={currentNav}
        onNavigate={(nav) => setCurrentNav(nav)}
        onOpenHelpDesk={() => setIsHelpDeskOpen(true)}
        isMobileOpen={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />

      {/* Main Content Column */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        {/* Top Header Bar */}
        <Header
          pageTitle={getPageTitle()}
          onOpenNotifications={() => setIsNotificationOpen(true)}
          onOpenSearch={() => setIsSearchOpen(true)}
          onOpenMobileMenu={() => setIsMobileSidebarOpen(true)}
          onNavigateSettings={() => setCurrentNav('settings')}
        />

        {/* Content View Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {currentNav === 'overview' && (
            <OverviewView
              onNewComplaint={() => setCurrentNav('new-complaint')}
              onViewAllComplaints={() => setCurrentNav('my-complaints')}
              onSelectComplaint={(id) => setSelectedComplaintId(id)}
              onOpenHelpDesk={() => setIsHelpDeskOpen(true)}
            />
          )}

          {currentNav === 'my-complaints' && (
            <MyComplaintsView
              onNewComplaint={() => setCurrentNav('new-complaint')}
              onSelectComplaint={(id) => setSelectedComplaintId(id)}
            />
          )}

          {currentNav === 'new-complaint' && (
            <NewComplaintView
              onSuccess={(id) => {
                setSelectedComplaintId(id);
                setCurrentNav('my-complaints');
              }}
              onCancel={() => setCurrentNav('overview')}
            />
          )}

          {currentNav === 'notifications' && (
            <NotificationsView
              onSelectComplaint={(id) => setSelectedComplaintId(id)}
            />
          )}

          {currentNav === 'admin-analytics' && <AdminAnalyticsView />}

          {currentNav === 'all-complaints' && (
            <AllComplaintsAdminView
              onSelectComplaint={(id) => setSelectedComplaintId(id)}
            />
          )}

          {currentNav === 'users-access' && <UsersAccessView />}

          {currentNav === 'categories-locations' && <CategoriesLocationsView />}

          {currentNav === 'reports-activity' && <AdminAnalyticsView />}

          {currentNav === 'settings' && <SettingsView />}

          {currentNav === 'maintenance-tasks' && (
            <MaintenanceTasksView
              onSelectComplaint={(id) => setSelectedComplaintId(id)}
            />
          )}
        </main>
      </div>

      {/* Global Modals */}
      <ComplaintDetailModal
        complaintId={selectedComplaintId}
        onClose={() => setSelectedComplaintId(null)}
      />

      <NotificationDrawer
        isOpen={isNotificationOpen}
        onClose={() => setIsNotificationOpen(false)}
        onSelectComplaint={(id) => setSelectedComplaintId(id)}
      />

      <HelpDeskModal
        isOpen={isHelpDeskOpen}
        onClose={() => setIsHelpDeskOpen(false)}
      />

      <CommandPaletteModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectComplaint={(id) => setSelectedComplaintId(id)}
        onNewComplaint={() => setCurrentNav('new-complaint')}
      />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
