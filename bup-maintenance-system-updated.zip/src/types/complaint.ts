export type UserRole = 'student' | 'faculty' | 'officer' | 'maintenance' | 'admin' | 'authority';

export type ComplaintPriority = 'Low' | 'Medium' | 'High' | 'Emergency';

export type ComplaintStatus = 'Pending' | 'Assigned' | 'In Progress' | 'Resolved' | 'Closed' | 'Rejected';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  userType: 'student' | 'faculty' | 'officer' | 'staff' | 'admin';
  role: UserRole;
  studentOrEmployeeId: string;
  departmentName: string;
  avatar?: string;
}

export interface ComplaintCategory {
  id: string;
  name: string;
  description: string;
  iconName: string;
  departmentId: string;
  defaultPriority: ComplaintPriority;
}

export interface CampusLocation {
  id: string;
  buildingName: string;
  floor: string;
  roomArea: string;
}

export interface StatusHistoryItem {
  id: string;
  complaintId: string;
  status: ComplaintStatus;
  updatedBy: string;
  updatedByName: string;
  role: string;
  updatedDate: string;
  remarks: string;
}

export interface ComplaintAssignment {
  id: string;
  complaintId: string;
  staffId: string;
  staffName: string;
  departmentId: string;
  assignedDate: string;
  notes?: string;
}

export interface Complaint {
  id: string; // e.g. BUP-CMP-2026-001
  title: string;
  description: string;
  categoryId: string;
  categoryName: string;
  locationId: string;
  buildingName: string;
  floor: string;
  roomArea: string;
  priority: ComplaintPriority;
  status: ComplaintStatus;
  imageUrl?: string;
  resolutionImageUrl?: string;
  
  // Submitter details
  userId: string;
  userName: string;
  userEmail: string;
  userPhone: string;
  userType: string;
  studentOrEmployeeId: string;
  submissionDate: string;
  
  // Assignment details
  assignedStaffId?: string;
  assignedStaffName?: string;
  departmentId?: string;
  departmentName?: string;
  assignedDate?: string;
  
  // Resolution details
  resolvedDate?: string;
  resolutionRemarks?: string;
  closedDate?: string;
  rejectionReason?: string;
  
  // Feedback
  feedbackRating?: number; // 1 to 5
  feedbackComment?: string;
  feedbackDate?: string;
}

export interface MaintenanceStaff {
  id: string;
  name: string;
  email: string;
  phone: string;
  departmentId: string;
  departmentName: string;
  specialization: string;
  activeTasksCount: number;
}

export interface Department {
  id: string;
  name: string;
  contactInfo: string;
  headName: string;
  email: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  complaintId: string;
  message: string;
  notificationDate: string;
  isRead: boolean;
  type: 'status_update' | 'assignment' | 'resolution' | 'rejection' | 'feedback';
}
