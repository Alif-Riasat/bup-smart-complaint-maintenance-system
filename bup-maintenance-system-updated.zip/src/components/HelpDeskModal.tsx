import React from 'react';
import { X, Phone, Mail, Building2, Clock, ShieldCheck } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface HelpDeskModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpDeskModal: React.FC<HelpDeskModalProps> = ({ isOpen, onClose }) => {
  const { departments } = useApp();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs font-sans">
      <div className="bg-white rounded-2xl w-full max-w-lg p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 border border-zinc-200">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-100">
          <div>
            <h3 className="font-bold text-base text-zinc-900">Campus Maintenance Help Desk</h3>
            <p className="text-xs text-zinc-500">Urgent reporting &amp; department contact directory</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-700 hover:bg-zinc-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3">
          <div className="p-3.5 rounded-xl bg-amber-50/80 border border-amber-200 text-xs text-amber-900 flex items-start gap-2.5">
            <Clock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold block">For Life Safety / Critical Emergencies:</span>
              <span>
                Call campus central control immediately or visit Estate Office at Academic Block Ground Floor.
              </span>
            </div>
          </div>

          <div className="space-y-2">
            {departments.map((dept) => (
              <div key={dept.id} className="p-3.5 rounded-xl bg-zinc-50 border border-zinc-200/80 text-xs space-y-1">
                <div className="font-bold text-zinc-900">{dept.name}</div>
                <div className="flex items-center justify-between text-zinc-500 pt-1">
                  <span className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-zinc-400" />
                    <span className="font-mono text-zinc-800 font-semibold">{dept.contactInfo}</span>
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-zinc-400" />
                    <span>{dept.email}</span>
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="pt-2 border-t border-zinc-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-black hover:bg-zinc-800 text-white text-xs font-semibold"
          >
            Close help desk
          </button>
        </div>
      </div>
    </div>
  );
};
