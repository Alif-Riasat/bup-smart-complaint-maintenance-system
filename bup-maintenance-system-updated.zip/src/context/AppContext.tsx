import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  Complaint,
  ComplaintCategory,
  CampusLocation,
  Department,
  MaintenanceStaff,
  StatusHistoryItem,
  NotificationItem,
  ComplaintStatus,
  ComplaintPriority,
} from '../types/complaint';
import {
  INITIAL_COMPLAINTS,
  INITIAL_USERS,
  INITIAL_CATEGORIES,
  INITIAL_LOCATIONS,
  INITIAL_DEPARTMENTS,
  INITIAL_MAINTENANCE_STAFF,
  INITIAL_STATUS_HISTORY,
  INITIAL_NOTIFICATIONS,
} from '../data/seedData';

interface AppContextType {
  currentUser: User;
  setCurrentUser: (user: User) => void;
  availableUsers: User[];
  isAuthenticated: boolean;
  login: (user: User) => void;
  logout: () => void;
  registerUser: (userData: Omit<User, 'id'>) => User;
  
  complaints: Complaint[];
  categories: ComplaintCategory[];
  locations: CampusLocation[];
  departments: Department[];
  maintenanceStaff: MaintenanceStaff[];
  statusHistory: StatusHistoryItem[];
  notifications: NotificationItem[];
  
  // Actions
  submitComplaint: (data: {
    title: string;
    description: string;
    categoryId: string;
    locationId: string;
    priority: ComplaintPriority;
    imageUrl?: string;
  }) => Complaint;
  
  assignComplaint: (
    complaintId: string,
    staffId: string,
    priority?: ComplaintPriority,
    notes?: string
  ) => void;
  
  updateStaffProgress: (
    complaintId: string,
    newStatus: 'In Progress' | 'Resolved',
    remarks: string,
    resolutionImageUrl?: string
  ) => void;
  
  rejectComplaint: (complaintId: string, reason: string) => void;
  
  closeComplaint: (complaintId: string, remarks?: string) => void;
  
  submitFeedback: (complaintId: string, rating: number, comment?: string) => void;
  
  addCategory: (category: Omit<ComplaintCategory, 'id'>) => void;
  addLocation: (location: Omit<CampusLocation, 'id'>) => void;
  
  markNotificationAsRead: (notificationId: string) => void;
  markAllNotificationsAsRead: () => void;
  
  resetToDefaultData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  COMPLAINTS: 'bup_complaints_v1',
  HISTORY: 'bup_status_history_v1',
  NOTIFICATIONS: 'bup_notifications_v1',
  CATEGORIES: 'bup_categories_v1',
  LOCATIONS: 'bup_locations_v1',
  CURRENT_USER: 'bup_current_user_v1',
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('bup_session_active_v1') === 'true';
  });

  const [availableUsers, setAvailableUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('bup_users_list_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
    return INITIAL_USERS;
  });

  const [currentUser, setCurrentUser] = useState<User>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
    return INITIAL_USERS[0]; // Nusrat Jahan by default
  });

  const login = (user: User) => {
    setCurrentUser(user);
    setIsAuthenticated(true);
    sessionStorage.setItem('bup_session_active_v1', 'true');
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  };

  const logout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('bup_session_active_v1');
  };

  const registerUser = (userData: Omit<User, 'id'>): User => {
    const newUser: User = {
      ...userData,
      id: `user-${Date.now()}`,
    };
    const updated = [newUser, ...availableUsers];
    setAvailableUsers(updated);
    localStorage.setItem('bup_users_list_v1', JSON.stringify(updated));
    login(newUser);
    return newUser;
  };

  const [complaints, setComplaints] = useState<Complaint[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.COMPLAINTS);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
    return INITIAL_COMPLAINTS;
  });

  const [categories, setCategories] = useState<ComplaintCategory[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
    return INITIAL_CATEGORIES;
  });

  const [locations, setLocations] = useState<CampusLocation[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LOCATIONS);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
    return INITIAL_LOCATIONS;
  });

  const [statusHistory, setStatusHistory] = useState<StatusHistoryItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.HISTORY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
    return INITIAL_STATUS_HISTORY;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
    return INITIAL_NOTIFICATIONS;
  });

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.COMPLAINTS, JSON.stringify(complaints));
  }, [complaints]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(statusHistory));
  }, [statusHistory]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LOCATIONS, JSON.stringify(locations));
  }, [locations]);

  // Helper date formatter
  const getCurrentFormattedTime = () => {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return `${dateStr} ${timeStr}`;
  };

  // Submit Complaint (Student / Faculty / Officer)
  const submitComplaint = (data: {
    title: string;
    description: string;
    categoryId: string;
    locationId: string;
    priority: ComplaintPriority;
    imageUrl?: string;
  }): Complaint => {
    const category = categories.find((c) => c.id === data.categoryId);
    const location = locations.find((l) => l.id === data.locationId);
    
    // Unique ID generation per proposal FR-04
    const newSeq = complaints.length + 1;
    const formattedId = `BUP-CMP-2026-${String(newSeq).padStart(3, '0')}`;
    const timestamp = getCurrentFormattedTime();

    const newComplaint: Complaint = {
      id: formattedId,
      title: data.title,
      description: data.description,
      categoryId: data.categoryId,
      categoryName: category?.name || 'General',
      locationId: data.locationId,
      buildingName: location?.buildingName || 'Campus Main Area',
      floor: location?.floor || 'Ground Level',
      roomArea: location?.roomArea || 'Main Area',
      priority: data.priority,
      status: 'Pending',
      imageUrl: data.imageUrl,
      userId: currentUser.id,
      userName: currentUser.name,
      userEmail: currentUser.email,
      userPhone: currentUser.phone,
      userType: currentUser.userType,
      studentOrEmployeeId: currentUser.studentOrEmployeeId,
      submissionDate: timestamp,
    };

    // Add status history entry
    const newHistory: StatusHistoryItem = {
      id: `hist-${Date.now()}`,
      complaintId: formattedId,
      status: 'Pending',
      updatedBy: currentUser.id,
      updatedByName: currentUser.name,
      role: currentUser.role,
      updatedDate: timestamp,
      remarks: 'Complaint registered by user in portal.',
    };

    // Notification for user and admins
    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      userId: currentUser.id,
      complaintId: formattedId,
      message: `Your complaint #${formattedId} "${data.title}" was registered successfully. Status: Pending.`,
      notificationDate: timestamp,
      isRead: false,
      type: 'status_update',
    };

    setComplaints((prev) => [newComplaint, ...prev]);
    setStatusHistory((prev) => [...prev, newHistory]);
    setNotifications((prev) => [newNotif, ...prev]);

    return newComplaint;
  };

  // Assign Complaint (Admin action - FR-07)
  const assignComplaint = (
    complaintId: string,
    staffId: string,
    priority?: ComplaintPriority,
    notes?: string
  ) => {
    const staff = INITIAL_MAINTENANCE_STAFF.find((s) => s.id === staffId);
    if (!staff) return;

    const timestamp = getCurrentFormattedTime();

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id === complaintId) {
          return {
            ...c,
            status: 'Assigned',
            assignedStaffId: staff.id,
            assignedStaffName: staff.name,
            departmentId: staff.departmentId,
            departmentName: staff.departmentName,
            assignedDate: timestamp,
            priority: priority || c.priority,
          };
        }
        return c;
      })
    );

    const historyItem: StatusHistoryItem = {
      id: `hist-${Date.now()}`,
      complaintId,
      status: 'Assigned',
      updatedBy: currentUser.id,
      updatedByName: currentUser.name,
      role: currentUser.role,
      updatedDate: timestamp,
      remarks: `Assigned to ${staff.name} (${staff.departmentName}). ${notes ? 'Notes: ' + notes : ''}`,
    };

    // Notify the submitter
    const targetComplaint = complaints.find((c) => c.id === complaintId);
    if (targetComplaint) {
      const notif: NotificationItem = {
        id: `notif-${Date.now()}`,
        userId: targetComplaint.userId,
        complaintId,
        message: `Complaint #${complaintId} has been assigned to ${staff.name} (${staff.departmentName}).`,
        notificationDate: timestamp,
        isRead: false,
        type: 'assignment',
      };
      setNotifications((prev) => [notif, ...prev]);
    }

    setStatusHistory((prev) => [...prev, historyItem]);
  };

  // Update Progress by Maintenance Staff (FR-08)
  const updateStaffProgress = (
    complaintId: string,
    newStatus: 'In Progress' | 'Resolved',
    remarks: string,
    resolutionImageUrl?: string
  ) => {
    const timestamp = getCurrentFormattedTime();

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id === complaintId) {
          return {
            ...c,
            status: newStatus,
            ...(newStatus === 'Resolved'
              ? {
                  resolvedDate: timestamp,
                  resolutionRemarks: remarks,
                  resolutionImageUrl: resolutionImageUrl || c.resolutionImageUrl,
                }
              : {}),
          };
        }
        return c;
      })
    );

    const historyItem: StatusHistoryItem = {
      id: `hist-${Date.now()}`,
      complaintId,
      status: newStatus,
      updatedBy: currentUser.id,
      updatedByName: currentUser.name,
      role: currentUser.role,
      updatedDate: timestamp,
      remarks: remarks || `Maintenance staff marked complaint as ${newStatus}.`,
    };

    const targetComplaint = complaints.find((c) => c.id === complaintId);
    if (targetComplaint) {
      const notif: NotificationItem = {
        id: `notif-${Date.now()}`,
        userId: targetComplaint.userId,
        complaintId,
        message:
          newStatus === 'Resolved'
            ? `Complaint #${complaintId} has been marked RESOLVED by technician. Please review and provide your rating!`
            : `Technician ${currentUser.name} has begun work on complaint #${complaintId}.`,
        notificationDate: timestamp,
        isRead: false,
        type: newStatus === 'Resolved' ? 'resolution' : 'status_update',
      };
      setNotifications((prev) => [notif, ...prev]);
    }

    setStatusHistory((prev) => [...prev, historyItem]);
  };

  // Reject Complaint (Admin / Authority)
  const rejectComplaint = (complaintId: string, reason: string) => {
    const timestamp = getCurrentFormattedTime();

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id === complaintId) {
          return {
            ...c,
            status: 'Rejected',
            rejectionReason: reason,
          };
        }
        return c;
      })
    );

    const historyItem: StatusHistoryItem = {
      id: `hist-${Date.now()}`,
      complaintId,
      status: 'Rejected',
      updatedBy: currentUser.id,
      updatedByName: currentUser.name,
      role: currentUser.role,
      updatedDate: timestamp,
      remarks: `Complaint rejected. Reason: ${reason}`,
    };

    const targetComplaint = complaints.find((c) => c.id === complaintId);
    if (targetComplaint) {
      const notif: NotificationItem = {
        id: `notif-${Date.now()}`,
        userId: targetComplaint.userId,
        complaintId,
        message: `Complaint #${complaintId} was rejected by Administration. Reason: "${reason}"`,
        notificationDate: timestamp,
        isRead: false,
        type: 'rejection',
      };
      setNotifications((prev) => [notif, ...prev]);
    }

    setStatusHistory((prev) => [...prev, historyItem]);
  };

  // Close Complaint (Admin / User confirms resolution)
  const closeComplaint = (complaintId: string, remarks?: string) => {
    const timestamp = getCurrentFormattedTime();

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id === complaintId) {
          return {
            ...c,
            status: 'Closed',
            closedDate: timestamp,
          };
        }
        return c;
      })
    );

    const historyItem: StatusHistoryItem = {
      id: `hist-${Date.now()}`,
      complaintId,
      status: 'Closed',
      updatedBy: currentUser.id,
      updatedByName: currentUser.name,
      role: currentUser.role,
      updatedDate: timestamp,
      remarks: remarks || 'Complaint verified and officially closed.',
    };

    setStatusHistory((prev) => [...prev, historyItem]);
  };

  // Submit Feedback & Rating (Student / Submitter - Use Case Diagram Figure 02)
  const submitFeedback = (complaintId: string, rating: number, comment?: string) => {
    const timestamp = getCurrentFormattedTime();

    setComplaints((prev) =>
      prev.map((c) => {
        if (c.id === complaintId) {
          return {
            ...c,
            feedbackRating: rating,
            feedbackComment: comment,
            feedbackDate: timestamp,
            status: c.status === 'Resolved' ? 'Closed' : c.status,
            closedDate: timestamp,
          };
        }
        return c;
      })
    );

    const historyItem: StatusHistoryItem = {
      id: `hist-${Date.now()}`,
      complaintId,
      status: 'Closed',
      updatedBy: currentUser.id,
      updatedByName: currentUser.name,
      role: currentUser.role,
      updatedDate: timestamp,
      remarks: `User provided feedback rating ${rating}/5 stars. Complaint closed.`,
    };

    setStatusHistory((prev) => [...prev, historyItem]);
  };

  const addCategory = (cat: Omit<ComplaintCategory, 'id'>) => {
    const newCat: ComplaintCategory = {
      ...cat,
      id: `cat-${Date.now()}`,
    };
    setCategories((prev) => [...prev, newCat]);
  };

  const addLocation = (loc: Omit<CampusLocation, 'id'>) => {
    const newLoc: CampusLocation = {
      ...loc,
      id: `loc-${Date.now()}`,
    };
    setLocations((prev) => [...prev, newLoc]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  const resetToDefaultData = () => {
    localStorage.clear();
    setComplaints(INITIAL_COMPLAINTS);
    setCategories(INITIAL_CATEGORIES);
    setLocations(INITIAL_LOCATIONS);
    setStatusHistory(INITIAL_STATUS_HISTORY);
    setNotifications(INITIAL_NOTIFICATIONS);
    setCurrentUser(INITIAL_USERS[0]);
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        availableUsers,
        isAuthenticated,
        login,
        logout,
        registerUser,
        complaints,
        categories,
        locations,
        departments: INITIAL_DEPARTMENTS,
        maintenanceStaff: INITIAL_MAINTENANCE_STAFF,
        statusHistory,
        notifications,
        submitComplaint,
        assignComplaint,
        updateStaffProgress,
        rejectComplaint,
        closeComplaint,
        submitFeedback,
        addCategory,
        addLocation,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        resetToDefaultData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
