# BUP Smart Complaint & Maintenance Management System

A centralized digital complaint and campus maintenance management platform built for **Bangladesh University of Professionals (BUP)** (Department of ICT, Faculty of Science & Technology).

---

## 🚀 Quick Start Guide (Run on Local Machine)

Follow these simple steps to run this application on your local machine (Mac, Windows, or Linux). **No MySQL or external database setup is needed**; everything runs out-of-the-box using fast local state management.

### Prerequisites
- **Node.js**: Version 18.0.0 or higher ([Download Node.js](https://nodejs.org/))
- **npm** (included with Node.js) or **pnpm** / **yarn** / **bun**

---

### Step 1: Open Terminal in Project Directory
Open your Terminal (Mac/Linux) or Command Prompt / PowerShell (Windows) and navigate into the project directory:

```bash
cd bup-maintenance-system
```

---

### Step 2: Install Dependencies
Run the install command to download all required packages:

```bash
npm install
```

---

### Step 3: Start the Local Development Server
Start the development server:

```bash
npm run dev
```

You will see output similar to:
```
  VITE v6.x.x  ready in 250 ms

  ➜  Local:   http://localhost:3000/
  ➜  Network: use --host to expose
```

---

### Step 4: Open in Browser
Open your browser and navigate to:
```
http://localhost:3000
```

---

## 🗄️ How to View the Database in MySQL Terminal

The project includes a ready-to-run SQL schema file: **`database_schema.sql`** with preloaded sample complaints, registered users, campus emergency numbers, and maintenance servicers.

### Step-by-Step Terminal Commands:

#### 1. Open MySQL in your terminal:
```bash
mysql -u root -p
```
*(Enter your MySQL password when prompted)*

#### 2. Create the database and import the schema:
```sql
CREATE DATABASE IF NOT EXISTS bup_maintenance;
USE bup_maintenance;
SOURCE database_schema.sql;
```

#### 3. View the created tables:
```sql
SHOW TABLES;
```
Output:
```
+---------------------------+
| Tables_in_bup_maintenance |
+---------------------------+
| campus_locations          |
| complaint_categories      |
| complaints                |
| departments               |
| emergency_contacts        |
| maintenance_staff         |
| users                     |
+---------------------------+
```

#### 4. Query complaints, users, and campus servicers:
```sql
-- View all submitted complaints:
SELECT id, title, category_name, priority, status, submitted_by_name FROM complaints;

-- View registered students, faculty, and administrators:
SELECT id, name, role, email, phone FROM users;

-- View certified campus servicers and active repair tasks:
SELECT name, department_name, specialization, phone, active_tasks FROM maintenance_staff;

-- View 24/7 campus emergency contact numbers:
SELECT title, phone, mobile, ext, availability FROM emergency_contacts;
```

---

## 🔑 Login & Test Accounts

You can sign in with any of the pre-configured university accounts or register a brand new account using the **Register New** tab beside the login form:

| Role | Name / Title | ID or Email | Target Role Tab |
| :--- | :--- | :--- | :--- |
| **Student** | Nusrat Jahan | `24549010088` or `nusrat.24549010088@bup.edu.bd` | `student` |
| **Faculty** | Suman Saha (Asst. Prof) | `FAC-IOT-108` or `suman.saha@bup.edu.bd` | `faculty` |
| **Administrator** | Col (Retd) Zahid Hasan | `ADM-BUP-001` or `admin.maintenance@bup.edu.bd` | `admin` |
| **Field Technician** | Rafiqul Islam (HVAC/Electrical) | `STF-ELEC-401` or `rafiqul.maint@bup.edu.bd` | `maintenance` |

> *Tip: Any password works for testing (e.g. `123456`). You can also register your own custom student or staff account instantly on the landing page.*

---

## 🛠️ Project Structure

```
├── src/
│   ├── components/         # Reusable UI components (Header, Sidebar, Modals)
│   ├── context/            # React Context (AppContext - auth, users, complaints state)
│   ├── data/               # Seed data for complaints, locations, wings & users
│   ├── features/
│   │   ├── auth/           # Public Landing Page & Login/Register Form
│   │   ├── dashboard/      # Overview, New Complaint, and My Complaints views
│   │   ├── admin/          # Admin triage, analytics, user management, wings
│   │   ├── maintenance/    # Field technician work order execution & resolution
│   │   └── user/           # Complaint detail modals, rating and feedback
│   ├── types/              # TypeScript interfaces and data models
│   ├── utils/              # Utilities & offline zip exporter
│   ├── App.tsx             # Main routing and authenticated view switcher
│   └── main.tsx            # Application entry point
├── package.json            # Scripts & project dependencies
├── vite.config.ts          # Vite build configuration
└── index.html              # HTML shell
```

---

## 🧭 UI Path Map & HTML/Text Customization Guide

In this React + Vite single-page application, HTML and user interface content is organized modularly. Below is the exact file path for every screen and component:

### 1. HTML Meta & Browser Tab Information
| What to Change | Exact File Path | What to Edit |
| :--- | :--- | :--- |
| **Browser Title & Meta** | `/index.html` | `<title>`, `<meta name="description">`, OpenGraph tags, favicons |
| **Global Font & Styling** | `/src/index.css` | Tailwind styling, custom fonts, scrollbars |
| **App Shell Mounting** | `/src/main.tsx` | Entry point that mounts the React app into `#root` |

### 2. Public Landing Page, Login & Registration
| UI Screen | Exact File Path | What You Can Customize Inside |
| :--- | :--- | :--- |
| **Landing Page & Hero** | `/src/features/auth/LoginPage.tsx` | University title, tagline, banner text, stats cards |
| **Login & Register Form** | `/src/features/auth/LoginPage.tsx` | ID/Email fields, role dropdown, registration form |
| **Emergency Contacts List**| `/src/features/auth/LoginPage.tsx` | Emergency phone numbers, medical centre, campus security |
| **Test Account Cards** | `/src/features/auth/LoginPage.tsx` | Demo credentials helper section |

### 3. Student & Faculty Screens
| UI Screen | Exact File Path | What You Can Customize Inside |
| :--- | :--- | :--- |
| **Student Overview** | `/src/features/dashboard/OverviewView.tsx` | Metrics summary, welcome banner, quick action cards |
| **Submit New Complaint** | `/src/features/dashboard/NewComplaintView.tsx` | Complaint submission form (title, wing, room, photos) |
| **My Complaints Table** | `/src/features/dashboard/MyComplaintsView.tsx` | Submitted complaints list, status filters, search bar |
| **Ticket Details & Rating**| `/src/features/user/ComplaintDetailModal.tsx` | Ticket status timeline, technician details, rating stars |

### 4. Admin Management Screens
| UI Screen | Exact File Path | What You Can Customize Inside |
| :--- | :--- | :--- |
| **All Complaints Board** | `/src/features/admin/AllComplaintsAdminView.tsx` | Master complaint triage table, filtering by department |
| **Triage & Assign Modal** | `/src/features/admin/AdminComplaintTriageModal.tsx` | Technician assignment dropdown, priority picker |
| **Analytics & Reports** | `/src/features/admin/AdminAnalyticsView.tsx` | Resolution graphs, SLA charts, department stats |
| **Campus Wings & Categories**| `/src/features/admin/CategoriesLocationsView.tsx` | Academic building list, department wings, room types |
| **Users & Roles Directory**| `/src/features/admin/UsersAccessView.tsx` | Registered user table, role promotions |

### 5. Maintenance & Field Technician Screens
| UI Screen | Exact File Path | What You Can Customize Inside |
| :--- | :--- | :--- |
| **Technician Work Orders** | `/src/features/maintenance/MaintenanceTasksView.tsx` | Assigned work order cards, status updater, completion proof |

### 6. Common Navigation & Modals
| UI Component | Exact File Path | What You Can Customize Inside |
| :--- | :--- | :--- |
| **Top Navbar & Profile** | `/src/components/Header.tsx` | Top header, user profile badge, quick search trigger |
| **Sidebar Menu** | `/src/components/Sidebar.tsx` | Left sidebar menu navigation items and icons |
| **Help Desk Popup** | `/src/components/HelpDeskModal.tsx` | University helpline phone numbers, guidelines, FAQs |
| **Notification Drawer** | `/src/components/NotificationDrawer.tsx` | Ticket alerts, assignment notices drawer |
| **Command Search (Cmd+K)**| `/src/components/CommandPaletteModal.tsx` | Global search modal |

### 7. Initial Data & Data Types
| Data / Schema | Exact File Path | Purpose |
| :--- | :--- | :--- |
| **Default Data & Phones** | `/src/data/seedData.ts` | Default users, initial tickets, campus wings, contact numbers |
| **TypeScript Types** | `/src/types/complaint.ts` | Data models for tickets, user roles, priorities, categories |

---

## 📦 Building for Production

To create an optimized production build:

```bash
npm run build
```

To preview the production build locally:

```bash
npm run preview
```
